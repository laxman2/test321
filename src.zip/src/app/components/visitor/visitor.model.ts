export class Visitor {
    id: number;
    name: string;
    inTime: string;
    outTime: string;
    purpose: string;
    mobile: number;
    idProof: string;
}