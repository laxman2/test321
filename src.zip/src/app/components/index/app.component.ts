/**
 * Created By : Laxman Kanhere (http://laxmank.in)
 */

import { Component } from '@angular/core';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.css']
})


export class AppComponent {
	title = 'Visitor By Laxman Kanhere';
// Add Visitor Entry
// 	Name

// 2. In Time: DD-MM-YYYY hh:mm:ss

// 3. Out Time: DD-MM-YYYY hh:mm:ss

// 4. Purpose of Visit

// 5. Point of Contact

// 6. Mobile Number

// 7. ID proo
	visitorsList = [
			{
				id : 1,
				name : 'Laxman Kanhere',
				inTime : '12:11:00',
				outTime : '05:11:00',
				purpose : 'Client Meeting',
				mobile : '4343432667',
				idProof : 'Adhar Card'
			},
			{
				id : 2,
				name : 'Tushar ',
				inTime : '12:11:00',
				outTime : '05:11:00',
				purpose : 'Interview',
				mobile : '0987676455',
				idProof : 'Adhar Card'
			},
			{
				id : 3,
				name : 'Sarfraj',
				inTime : '12:11:00',
				outTime : '05:11:00',
				purpose : 'Client Meeting',
				mobile : '1234567890',
				idProof : 'Adhar Card'
			},
			{
				id : 4,
				name : 'Tej',
				inTime : '10:11:00',
				outTime : '03:11:00',
				purpose : 'Visiting ',
				mobile : '9854644488',
				idProof : 'Adhar Card'
			},
			{
				id : 5,
				name : 'Ashish',
				inTime : '10:11:00',
				outTime : '06:11:00',
				purpose : 'Interview',
				mobile : '1234567890',
				idProof : 'Adhar Card'
			}
			];

	constructor() {
		// Save VisitorsList to localStorage
		localStorage.setItem('VisitorsList', JSON.stringify(this.visitorsList));
	}
}

/**
 * Created By : Laxman Kanhere (http://laxmank.in)
 */
