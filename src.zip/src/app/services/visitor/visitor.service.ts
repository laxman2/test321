import { environment } from './../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class VisitorService {
  API_URL = environment.API_URL;
  constructor(private http: HttpClient) { }

  // Get all visitor list via API or any data storage
  getAllVisitorsList() {
    return this.http.get(`${this.API_URL}visitor/list`);
  }
  getVisitorDetails(index: number) {
    const visitorsList = JSON.parse(localStorage.getItem('VisitorsList'));
    const returnData = {
      code: 200,
      message: 'Visitors Details Fetched',
      visitorData: visitorsList[index]
    };
    return this.http.get(`${this.API_URL}visitor/list/` + index);

    return returnData;
  }

  doRegisterVisitor(data, index: number) {
    data.id = this.generateRandomID();
    console.log(JSON.stringify(data));
  return  this.http.post(`${this.API_URL}/visitor`, JSON.stringify(data));
    const visitorList = JSON.parse(localStorage.getItem('VisitorsList'));
    let returnData;
    if (index != null) {
      let i: number;
      for ( i = 0; i < visitorList.length; i++) {
        if (index != i && visitorList[i].mobile === data.mobile) {
          returnData = {
            code: 503,
            message: 'Phone Number Already In Use',
            data: null
          };
          return returnData;
        }
      }

      visitorList[index] = data;
     
      localStorage.setItem('VisitorsList', JSON.stringify(visitorList));
      returnData = {
        code: 200,
        message: 'Student Successfully Updated',
        data: JSON.parse(localStorage.getItem('VisitorsList'))
      };
    } else {
      data.id = this.generateRandomID();
      for (let i = 0; i < visitorList.length; i++) {
        if (visitorList[i].mobile === data.mobile) {
          returnData = {
            code: 503,
            message: 'Phone Number Already In Use',
            data: null
          };
          return returnData;
        }
      }
      visitorList.unshift(data);

      localStorage.setItem('VisitorsList', JSON.stringify(visitorList));
      returnData = {
        code: 200,
        message: 'Visitor Successfully Added',
        data: JSON.parse(localStorage.getItem('VisitorsList'))
      };
    }
    return returnData;
  }

  deleteVisitor(index: number) {
    const visitorsList = JSON.parse(localStorage.getItem('VisitorsList'));

    visitorsList.splice(index, 1);

    localStorage.setItem('VisitorsList', JSON.stringify(visitorsList));

    const returnData = {
      code: 200,
      message: 'Student Successfully Deleted',
      data: JSON.parse(localStorage.getItem('VisitorsList'))
    };

    return returnData;
  }
  generateRandomID() {
    const x = Math.floor((Math.random() * Math.random() * 9999));
    return x;
  }
}
