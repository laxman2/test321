/**
 * Created By : Laxman Kanhere (http://laxmank.in)
 */
import { VisitorService } from './../../../services/visitor/visitor.service';
import { ValidationService, routerTransition } from './../../../services/config/config.service';
import { ToastrService } from 'ngx-toastr';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
	selector: 'app-add',
	templateUrl: './add.component.html',
	styleUrls: ['./add.component.scss'],
})
export class AddComponent implements OnInit {
	visitorAddForm: FormGroup;
	index: any;

	constructor(private formBuilder: FormBuilder,
		private router: Router,
		private route: ActivatedRoute,
		private visitorService: VisitorService,
		private toastr: ToastrService) { }

	ngOnInit() {
		// Check for route params
		this.route.params.subscribe(params => {
			this.index = params['id'];
			// check if ID exists in route & call update or add methods accordingly
			if (this.index && this.index !== null && this.index !== undefined) {
				this.getVisitorDetails(this.index);
			} else {
				this.createForm(null);
			}
		});
	}
	// If this is update form, get user details and update form
	getVisitorDetails(index: number) {
		const visitorDetails = this.visitorService.getVisitorDetails(index);
		console.log(visitorDetails);
		this.createForm(visitorDetails);
	}
	// If this is update request then auto fill form
	createForm(data) {
		if (data === null) {
			this.visitorAddForm = this.formBuilder.group({
				name: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]],
				inTime: ['', [Validators.required]],
				outTime: ['', [Validators.required]],
				purpose: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]],
				mobile: ['', [Validators.required, ValidationService.checkLimit(5000000000, 9999999999)]],
				idProof: ['', [Validators.required]]
			});
		} else {
			this.visitorAddForm = this.formBuilder.group({
				name: [data.visitorData.name, [Validators.required, Validators.minLength(3), Validators.maxLength(50)]],
				inTime: [data.visitorData.inTime, [Validators.required]],
				outTime: [data.visitorData.outTime, [Validators.required]],
				purpose: [data.visitorData.purpose, [Validators.required, Validators.minLength(3), Validators.maxLength(50)]],
				mobile: [data.visitorData.mobile, [Validators.required, ValidationService.checkLimit(5000000000, 9999999999)]],
				idProof: [data.visitorData.idProof, [Validators.required]]
			});
		}
	}
	// Submit visitor details form
	doRegister() {
		if (this.index && this.index !== null && this.index !== undefined) {
			this.visitorAddForm.value.id = this.index;
		} else {
			this.index = null;
		}
		//console.log(this.visitorAddForm );
		let data = { 
			"id": this.generateRandomID(),
			"name": this.visitorAddForm.value.name,
			"inTime": this.visitorAddForm.value.inTime,
			"outTime": this.visitorAddForm.value.outTime,
			"purpose": this.visitorAddForm.value.purpose,
			"mobile": this.visitorAddForm.value.mobile,
			"idProof": this.visitorAddForm.value.idProof
		  };
		  console.log(data);

		const visitorAdd = this.visitorService.doRegisterVisitor(data, this.index).subscribe(response =>{
					this.toastr.success("Visitor Added Successfuly", 'Success');
					this.router.navigate(['/']);
		});
	}

	generateRandomID() {
		const x = Math.floor((Math.random() * Math.random() * 9999));
		return x;
	  }

}
/**
 * Created By : Laxman Kanhere (http://laxmank.in)
 */
