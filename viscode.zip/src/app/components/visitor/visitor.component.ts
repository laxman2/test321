import { Visitor } from './visitor.model';
/**
 * Created By : Laxman Kanhere (http://laxmank.in)
 */

import { VisitorService } from './../../services/visitor/visitor.service';
import { ToastrService } from 'ngx-toastr';
import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-visitor',
	templateUrl: './visitor.component.html',
	styleUrls: ['./visitor.component.scss']
})

export class VisitorComponent implements OnInit {
	visitorList: any;
	visitorListData: any;
	constructor(private visitorService: VisitorService, private toastr: ToastrService) { }
	ngOnInit() {
		this.getVisitorList();
	}
	// Get getVisitorList list from services
	getVisitorList() {
		// const visitorList = this.visitorService.getAllVisitorsList();
		this.visitorService.getAllVisitorsList().subscribe((data: Visitor[]) => {
			this.visitorListData = data;
		  });
	}
	// Delete a visitor with its index
	deleteVisitor(id: number) {
		// get confirm box for confirmation
		const r = confirm('Are you sure?');
		if (r === true) {
			const visitorDelete = this.visitorService.deleteVisitor(id).subscribe(response => {
				this.getVisitorList();
			});
			;
			if (visitorDelete) {
				this.toastr.success('Success', 'Visitor Deleted');
			}
			
		}
	}

}
/**
 * Created By : Laxman Kanhere (http://laxmank.in)
 */
