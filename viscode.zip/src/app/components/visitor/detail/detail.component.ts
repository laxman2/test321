import { environment } from './../../../../environments/environment';
import { Visitor } from './../visitor.model';
/**
 * Created By : Laxman Kanhere (http://laxmank.in)
 */

import { VisitorService } from './../../../services/visitor/visitor.service';
import { ToastrService } from 'ngx-toastr';
import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { routerTransition } from 'src/app/services/config/config.service';
import { HttpHeaders, HttpClient } from '@angular/common/http';

@Component({
	selector: 'app-detail',
	templateUrl: './detail.component.html',
	styleUrls: ['./detail.component.scss'],
	animations: [routerTransition()],
	host: { '[@routerTransition]': '' }
})
export class DetailComponent implements OnInit {
	index: any;
	visitorDetail: any;
	API_URL = environment.API_URL;
	constructor(private router: Router,
		private route: ActivatedRoute,
		private visitorService: VisitorService,
		private toastr: ToastrService,
		private http: HttpClient) {
		// Get user detail index number sent in params
		this.route.params.subscribe(params => {
			this.index = params['id'];
			if (this.index && this.index != null && this.index !== undefined) {
				this.getVisitorDetails(this.index);
			}
		});
	}
	// Get getVisitorDetails details
	getVisitorDetails(index: number) {
	//	const getvistorDetail = this.visitorService.getVisitorDetails(index);
		const headers = new HttpHeaders()
			.set('Content-Type', 'application/json');
		this.http.get(this.API_URL + 'visitor/get/' + index, { headers: headers, responseType: 'text' }).subscribe(response => {
			let data = response.replace(/\n/g, '');
			data = JSON.parse(data);
			this.visitorDetail = data;
		});


	}

	ngOnInit() {
	}

}
/**
 * Created By : Laxman Kanhere (http://laxmank.in)
 */
