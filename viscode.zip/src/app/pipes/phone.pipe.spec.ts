/**
 * Created By : Laxman Kanhere (http://laxmank.in)
 */

import { PhonePipe } from './phone.pipe';

describe('PhonePipe', () => {
  it('create an instance', () => {
    const pipe = new PhonePipe();
    expect(pipe).toBeTruthy();
  });
});


/**
 * Created By : Laxman Kanhere (http://laxmank.in)
 */