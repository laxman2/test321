import { HttpClientModule } from '@angular/common/http';
import {  HighlightVisitorDirective } from './directives/highlight-visitor.directive';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { enableProdMode } from '@angular/core';

// Modules
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';

// Services
import { AuthService } from './services/auth/auth.service';
import { UserService } from './services/user/user.service';

// Pipes
import { FilterPipe } from './pipes/filter.pipe';
import { PhonePipe } from './pipes/phone.pipe';

// Components
import { AppComponent } from './components/index/app.component';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent, homeChildRoutes } from './components/home/home.component';
import { AppRoutingModule } from './app-routing.module';
import { VisitorComponent } from './components/visitor/visitor.component';
import { DetailComponent } from './components/visitor/detail/detail.component';
import { VisitorService } from './services/visitor/visitor.service';
import { AddComponent } from './components/visitor/add/add.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';





@NgModule({
	declarations: [
		AppComponent,
		LoginComponent,
		HomeComponent,
		FilterPipe,
		PhonePipe,
		VisitorComponent,
		DetailComponent,
		AddComponent,
		HighlightVisitorDirective,
	],
	imports: [
		BrowserModule,
		HttpClientModule,
		RouterModule,
		AppRoutingModule,
		FormsModule,
		ReactiveFormsModule,
		BrowserAnimationsModule,
		NgbModule,
		ToastrModule.forRoot({
			timeOut: 3000,
			positionClass: 'toast-bottom-right',
			preventDuplicates: true,
		}),
	],
	providers: [AuthService, UserService, VisitorService],
	bootstrap: [AppComponent]
})

// enableProdMode();

export class AppModule { }
