import { environment } from './../../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class VisitorService {
  API_URL = environment.API_URL;
  constructor(private http: HttpClient) { }

  // Get all visitor list via API or any data storage
  getAllVisitorsList() {
    return this.http.get(`${this.API_URL}visitor/list`);
  }
  getVisitorDetails(index: number) {
    const visitorsList = JSON.parse(localStorage.getItem('VisitorsList'));
    const returnData = {
      code: 200,
      message: 'Visitors Details Fetched',
      visitorData: visitorsList[index]
    };
    return this.http.get(`${this.API_URL}visitor/list/` + index);

    return returnData;
  }

  doRegisterVisitor(data, index: number) {
    return  this.http.post(`${this.API_URL}visitor`, data);
  }

  deleteVisitor(id: any) {
    const headers = new HttpHeaders()
			.set('Content-Type', 'application/json');
    return  this.http.delete(`${this.API_URL}visitor/delete/` + id,  { headers: headers, responseType: 'text' });

  }
}
